---
modified: 2025-05-14T12:16
---
# De-Centralizedな法定通貨-暗号資産間の取引所を作る

https://dedeal.gitbook.io/whitepaper/v/ja/

JPY JPYC 各種通貨

JPYC 各種通貨はめっちゃ簡単なので

JPY JPYCがDe-Centralizedで手数料が安ければ一番いいのかなと

とは言え、発行業者が用意してくれる気がする。