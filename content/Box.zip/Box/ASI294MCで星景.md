---
modified: 2025-05-13T13:52
---


https://forums.sharpcap.co.uk/viewtopic.php?t=254

まずPIPPでDebayeringする。
※PIPPのサイトが終了したっぽいのでWayback Machineしか無い。
https://web.archive.org/web/20230604160543/https://sites.google.com/site/astropipp/home

PIPPはFITSに対応している。

