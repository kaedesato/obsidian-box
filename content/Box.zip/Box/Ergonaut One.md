---
modified: 2025-06-14T12:03
---
  

  ### Ergonaut Oneとは
- ErgonautはArgonautから来てます
    
    ギリシャ神話に出てくる船
    






  

### キースイッチとキーキャップ

キースイッチはGateronのLowProfile  
7種類くらいが市場にはある。  

  

キーキャップは薄めのキーキャップをおすすめします。  
これも、後述するJLCPCBで発注するのがおすすめです。  

  

### [[Ergonaut One パーツ準備編]]

  

  

### [[Ergonaut One 組み立て編]] 

  

  

### ファームウェア編

![[ZMKの使い方]]


おすすめ設定
